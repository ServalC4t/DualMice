// content.js
// Initialize the virtual cursor element
const cursorId = 'wmonitor-ghost-cursor';
let cursorEl = document.getElementById(cursorId);

if (!cursorEl) {
    cursorEl = document.createElement('div');
    cursorEl.id = cursorId;
    cursorEl.innerHTML = `
        <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" style="width: 100%; height: 100%; filter: drop-shadow(0px 1px 2px rgba(0,0,0,0.4));">
            <path id="ghost-cursor-path" d="M5.5 3.21V20.8c0 .45.54.67.85.35l4.83-4.83a.5.5 0 0 1 .35-.15h6.17c.45 0 .67-.54.35-.85L6.35 2.86c-.32-.32-.85-.1-.85.35z" fill="#00CCFF" stroke="white" stroke-width="1.2" stroke-linejoin="round"/>
        </svg>
    `;
    if (document.body) {
        document.body.appendChild(cursorEl);
    } else {
        document.addEventListener('DOMContentLoaded', () => {
            document.body.appendChild(cursorEl);
        });
    }
}

// ── Toolbar UI ──
let toolbarEl = document.getElementById('wmonitor-toolbar');
let keyboardMode = false;
let lastToolbarActionTime = 0;
const TOOLBAR_DEBOUNCE_MS = 600;

// ── Toolbar drag state ──
let isDraggingToolbar = false;
let dragOffsetX = 0;
let dragOffsetY = 0;
let toolbarPosX = 200;
let toolbarPosY = 4;

function createToolbar() {
    if (toolbarEl) return;
    toolbarEl = document.createElement('div');
    toolbarEl.id = 'wmonitor-toolbar';
    toolbarEl.innerHTML = `
        <div class="wm-handle" id="wmonitor-drag-handle">⠿</div>
        <div class="wm-row">
            <button data-action="histBack" class="wm-wide">← 戻る</button>
            <button data-action="histForward" class="wm-wide">→ 進む</button>
        </div>
        <div class="wm-row">
            <button data-action="newTab" data-tooltip="New Tab">＋</button>
            <button data-action="closeTab" data-tooltip="Close Tab">✕</button>
            <button data-action="prevTab" data-tooltip="Previous Tab">←</button>
            <button data-action="nextTab" data-tooltip="Next Tab">→</button>
            <button data-action="reloadTab" data-tooltip="Reload">↺</button>
            <button data-action="toggleKb" data-tooltip="Keyboard Input" id="wmonitor-kb-toggle">⌨</button>
        </div>
    `;

    const style = document.createElement('style');
    style.textContent = `
        #wmonitor-toolbar {
            position: fixed;
            top: 4px;
            left: 200px;
            z-index: 2147483646;
            user-select: none;
            display: none;
            flex-direction: column;
            gap: 2px;
            background: rgba(30, 30, 30, 0.92);
            border-radius: 6px;
            padding: 3px 4px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.5);
            pointer-events: none;
        }
        #wmonitor-toolbar .wm-row {
            display: flex;
            gap: 2px;
            align-items: center;
        }
        #wmonitor-toolbar button {
            pointer-events: auto;
            width: 28px;
            height: 28px;
            border: none;
            border-radius: 4px;
            background: rgba(255,255,255,0.1);
            color: #ccc;
            font-size: 15px;
            cursor: pointer;
            position: relative;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 0;
            line-height: 1;
            transition: background 0.15s;
        }
        #wmonitor-toolbar button:hover {
            background: rgba(255,255,255,0.25);
            color: #fff;
        }
        #wmonitor-toolbar button::after {
            content: attr(data-tooltip);
            position: absolute;
            top: 110%;
            left: 50%;
            transform: translateX(-50%);
            background: rgba(0,0,0,0.85);
            color: #eee;
            font-size: 11px;
            padding: 3px 7px;
            border-radius: 4px;
            white-space: nowrap;
            opacity: 0;
            pointer-events: none;
            transition: opacity 0.15s;
        }
        #wmonitor-toolbar button:hover::after {
            opacity: 1;
        }
        #wmonitor-toolbar button.wm-wide {
            width: auto;
            padding: 0 10px;
            font-size: 12px;
            letter-spacing: 0.5px;
        }
        #wmonitor-kb-toggle.active {
            background: rgba(0, 180, 255, 0.5);
            color: #fff;
        }
        .wm-handle {
            text-align: center;
            color: rgba(255,255,255,0.35);
            font-size: 13px;
            line-height: 10px;
            height: 10px;
            cursor: grab;
            letter-spacing: 3px;
            pointer-events: auto;
        }
        .wm-handle:hover {
            color: rgba(255,255,255,0.7);
        }
    `;

    if (document.head) {
        document.head.appendChild(style);
    } else {
        document.addEventListener('DOMContentLoaded', () => document.head.appendChild(style));
    }

    const appendToolbar = () => {
        document.body.appendChild(toolbarEl);

        // Mouse 1 drag support
        const handle = document.getElementById('wmonitor-drag-handle');
        let m1Dragging = false;
        let m1OffsetX = 0, m1OffsetY = 0;
        handle.addEventListener('mousedown', (e) => {
            m1Dragging = true;
            m1OffsetX = e.clientX - toolbarPosX;
            m1OffsetY = e.clientY - toolbarPosY;
            e.preventDefault();
        });
        document.addEventListener('mousemove', (e) => {
            if (!m1Dragging) return;
            toolbarPosX = Math.max(0, Math.min(e.clientX - m1OffsetX, window.innerWidth - toolbarEl.offsetWidth));
            toolbarPosY = Math.max(0, Math.min(e.clientY - m1OffsetY, window.innerHeight - toolbarEl.offsetHeight));
            toolbarEl.style.left = toolbarPosX + 'px';
            toolbarEl.style.top  = toolbarPosY + 'px';
        });
        document.addEventListener('mouseup', () => { m1Dragging = false; });
    };
    if (document.body) appendToolbar();
    else document.addEventListener('DOMContentLoaded', appendToolbar);
}
createToolbar();

// Handle toolbar button clicks / drag start via virtual cursor
function handleToolbarClick(x, y) {
    if (!toolbarEl || toolbarEl.style.display === 'none') return false;

    const toolbarRect = toolbarEl.getBoundingClientRect();
    if (x < toolbarRect.left || x > toolbarRect.right || y < toolbarRect.top || y > toolbarRect.bottom) return false;

    const buttons = toolbarEl.querySelectorAll('button');
    for (const btn of buttons) {
        const rect = btn.getBoundingClientRect();
        if (x >= rect.left && x <= rect.right && y >= rect.top && y <= rect.bottom) {
            const now = Date.now();
            if (now - lastToolbarActionTime < TOOLBAR_DEBOUNCE_MS) return true;
            lastToolbarActionTime = now;

            const action = btn.dataset.action;
            if (action === 'toggleKb') {
                keyboardMode = !keyboardMode;
                btn.classList.toggle('active', keyboardMode);
                if (ws && ws.readyState === WebSocket.OPEN) {
                    ws.send(JSON.stringify({ type: 'kbMode', active: keyboardMode }));
                }
            } else if (action === 'histBack') {
                window.history.back();
            } else if (action === 'histForward') {
                window.history.forward();
            } else if (action === 'reloadTab') {
                location.reload();
            } else {
                chrome.runtime.sendMessage({ action });
            }
            btn.style.background = 'rgba(0, 180, 255, 0.6)';
            setTimeout(() => { btn.style.background = ''; }, 150);
            return true;
        }
    }

    // ボタン以外のツールバー領域 → ドラッグ開始
    isDraggingToolbar = true;
    dragOffsetX = x - toolbarRect.left;
    dragOffsetY = y - toolbarRect.top;
    return true;
}

// ── Keyboard forwarding ──
document.addEventListener('keydown', (e) => {
    if (!keyboardMode) return;
    // Don't intercept if user is typing in an input/textarea already focused by Mouse 1
    // Keyboard mode means: allow all keyboard input to reach the page normally
    // This is the default behavior, so we just need to make sure nothing blocks it
}, true);

// ── WebSocket ──
let ws = null;
let currentX = 0;
let monitors = []; // C#から受信したモニター境界リスト
let currentY = 0;
let localX = 0;
let localY = 0;
let animationFrameId = null;
let mainCursorInBrowser = false;
let lastMoveTime = Date.now();
let lastMoveX = 0;
let lastMoveY = 0;
let mouse2Sleeping = false;
const SLEEP_MS = 3000;
const WAKE_PX = 38;   // ~1cm at 96dpi
const WAKE_MS = 1000; // 動き始めから1秒以内に1cm達成で復帰
let wakeStartTime = null;
let wakeStartX = 0;
let wakeStartY = 0;

// 3秒無操作でカーソル/ツールバーを非表示にするタイマー
setInterval(() => {
    if (!mouse2Sleeping && (Date.now() - lastMoveTime) >= SLEEP_MS) {
        mouse2Sleeping = true;
        if (cursorEl) cursorEl.style.display = 'none';
        if (toolbarEl) toolbarEl.style.display = 'none';
    }
}, 500);

function connectWebSocket() {
    ws = new WebSocket('ws://localhost:8080/');

    ws.onopen = () => {
        console.log('[WMonitor] Connected to Controller.');
    };

    ws.onmessage = (event) => {
        try {
            const data = JSON.parse(event.data);

            if (data.type === 'sync') {
                if (data.absX !== undefined) {
                    currentX = data.absX;
                    currentY = data.absY;
                } else {
                    currentX = data.x * window.innerWidth;
                    currentY = data.y * window.innerHeight;
                }

                // スリープ判定
                const dx = currentX - lastMoveX;
                const dy = currentY - lastMoveY;
                const moved = Math.sqrt(dx * dx + dy * dy);
                if (moved > 0) {
                    lastMoveTime = Date.now();
                    lastMoveX = currentX;
                    lastMoveY = currentY;

                    if (mouse2Sleeping) {
                        const now = Date.now();
                        if (wakeStartTime === null) {
                            // 動き始めを記録
                            wakeStartTime = now;
                            wakeStartX = currentX;
                            wakeStartY = currentY;
                        } else if (now - wakeStartTime > WAKE_MS) {
                            // 1秒経過してもダメ→ウィンドウリセット
                            wakeStartTime = now;
                            wakeStartX = currentX;
                            wakeStartY = currentY;
                        }
                        // 動き始めからの累計距離チェック
                        const tdx = currentX - wakeStartX;
                        const tdy = currentY - wakeStartY;
                        if (Math.sqrt(tdx * tdx + tdy * tdy) >= WAKE_PX) {
                            mouse2Sleeping = false;
                            wakeStartTime = null;
                        }
                    } else {
                        wakeStartTime = null; // 通常動作中はリセット
                    }
                }
                if (mouse2Sleeping) return;

                // Apply dynamic settings
                if (data.settings) {
                    const s = data.settings;
                    if (s.cursorImageData) {
                        // Custom image mode
                        const existing = cursorEl.querySelector('img.wm-custom-cursor');
                        if (!existing || existing.src !== s.cursorImageData) {
                            cursorEl.innerHTML = `<img class="wm-custom-cursor" src="${s.cursorImageData}" style="width:100%;height:100%;pointer-events:none;display:block;" />`;
                        }
                    } else {
                        // Default SVG mode
                        const hasCustom = cursorEl.querySelector('img.wm-custom-cursor');
                        if (hasCustom) {
                            cursorEl.innerHTML = `<svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" style="width:100%;height:100%;filter:drop-shadow(0px 1px 2px rgba(0,0,0,0.4));"><path id="ghost-cursor-path" d="M5.5 3.21V20.8c0 .45.54.67.85.35l4.83-4.83a.5.5 0 0 1 .35-.15h6.17c.45 0 .67-.54.35-.85L6.35 2.86c-.32-.32-.85-.1-.85.35z" fill="${s.cursorColor}" stroke="white" stroke-width="1.2" stroke-linejoin="round"/></svg>`;
                        }
                        const pathEl = document.getElementById('ghost-cursor-path');
                        if (pathEl) pathEl.setAttribute('fill', s.cursorColor);
                    }
                    cursorEl.style.width = s.cursorSize + 'px';
                    cursorEl.style.height = s.cursorSize + 'px';
                    cursorEl.style.opacity = s.opacity;
                }

                const screenX = window.screenX !== undefined ? window.screenX : window.screenLeft;
                const screenY = window.screenY !== undefined ? window.screenY : window.screenTop;
                const outerWidth = window.outerWidth;
                const outerHeight = window.outerHeight;

                // C#から受信したモニター境界で判定（JS側のwindow.outerWidthより正確）
                if (data.monitors && data.monitors.length > 0) {
                    monitors = data.monitors;
                }
                // このウィンドウが属するモニターを特定（screenXで判定）
                const myMon = monitors.find(m => screenX >= m.left && screenX < m.right)
                           || monitors.find(m => screenX >= m.left); // fallback
                const monLeft   = myMon ? myMon.left   : screenX;
                const monTop    = myMon ? myMon.top    : screenY;
                const monRight  = myMon ? myMon.right  : screenX + outerWidth;
                const monBottom = myMon ? myMon.bottom : screenY + outerHeight;

                // Bounds check: C#のモニター境界で判定
                if (currentX >= monLeft && currentX < monRight &&
                    currentY >= monTop  && currentY < monBottom) {

                    if (cursorEl.style.display !== 'block') {
                        cursorEl.style.display = 'block';
                    }
                    if (toolbarEl) toolbarEl.style.display = 'flex';

                    // ブラウザのズーム率を算出（outerWidth はズーム不変、innerWidth はズームで変わる）
                    // window chrome(ボーダー)を除いたビューポート物理幅 ≈ outerWidth（Chromeではほぼ同じ）
                    const zoomRatio = window.outerWidth / window.innerWidth;

                    localX = (currentX - screenX) / zoomRatio;
                    localY = (currentY - screenY) / zoomRatio;

                    // タイトルバー分を補正（ズーム適用後のCSS座標で）
                    const titleBarCSS = (outerHeight / zoomRatio) - window.innerHeight;
                    if (titleBarCSS > 0) localY -= titleBarCSS;

                    // Schedule a render
                    if (!animationFrameId) {
                        animationFrameId = requestAnimationFrame(updateCursorPosition);
                    }
                } else {
                    cursorEl.style.display = 'none';
                    if (toolbarEl) toolbarEl.style.display = 'none';
                }

                // アクティブなタブのみ処理（非表示タブのcontent scriptは無視）
                const cursorInThisWindow = cursorEl.style.display === 'block' && !document.hidden;

                // Handle scrolling (wheel) — カーソルがこのウィンドウにある時だけ
                if (data.deltaY !== 0 && cursorInThisWindow) {
                    if (window.location.pathname.includes('/shorts/')) {
                        // YouTube Shorts: 矢印キーで次/前のショートへ
                        const down = data.deltaY > 0;
                        const opts = {
                            key: down ? 'ArrowDown' : 'ArrowUp',
                            code: down ? 'ArrowDown' : 'ArrowUp',
                            keyCode: down ? 40 : 38,
                            which: down ? 40 : 38,
                            bubbles: true,
                            cancelable: true
                        };
                        // Shorts再生中の要素にフォーカスしてキー送信
                        const shortsPlayer = document.querySelector('ytd-reel-video-renderer[is-active]')
                                          || document.querySelector('#shorts-container')
                                          || document.activeElement;
                        shortsPlayer.dispatchEvent(new KeyboardEvent('keydown', opts));
                        setTimeout(() => shortsPlayer.dispatchEvent(new KeyboardEvent('keyup', opts)), 50);
                    } else {
                        window.scrollBy({ top: data.deltaY, behavior: 'instant' });
                    }
                }

                // Handle clicking — カーソルがこのウィンドウにある時だけ
                if (data.clickType === 'leftDown' && cursorInThisWindow) {
                    if (!handleToolbarClick(localX, localY)) {
                        triggerClick(localX, localY);
                    }
                }

                // Handle back/forward (side buttons) — カーソルがこのウィンドウにある時だけ
                if (cursorInThisWindow) {
                    if (data.clickType === 'back') {
                        window.history.back();
                    } else if (data.clickType === 'forward') {
                        window.history.forward();
                    }
                }

                // Toolbar drag move
                if (isDraggingToolbar && cursorInThisWindow && toolbarEl) {
                    toolbarPosX = Math.max(0, Math.min(localX - dragOffsetX, window.innerWidth - toolbarEl.offsetWidth));
                    toolbarPosY = Math.max(0, Math.min(localY - dragOffsetY, window.innerHeight - toolbarEl.offsetHeight));
                    toolbarEl.style.left = toolbarPosX + 'px';
                    toolbarEl.style.top  = toolbarPosY + 'px';
                }

                // leftUp → ドラッグ終了
                if (data.clickType === 'leftUp') {
                    isDraggingToolbar = false;
                }

            } else if (data.type === 'keyEvent' && keyboardMode && !document.hidden) {
                // キーボード転送 — アクティブタブのみ、キーボードモードON時
                const target = document.activeElement || document.body;
                const keyName = vkeyToKey(data.vkey);
                const opts = {
                    key: keyName,
                    keyCode: data.vkey,
                    which: data.vkey,
                    bubbles: true,
                    cancelable: true
                };
                target.dispatchEvent(new KeyboardEvent(data.eventType, opts));
                // テキスト入力フィールドへの文字入力
                if (data.eventType === 'keydown' && (target.tagName === 'INPUT' || target.tagName === 'TEXTAREA')) {
                    const start = target.selectionStart ?? target.value.length;
                    const end = target.selectionEnd ?? target.value.length;
                    if (data.vkey === 8) { // Backspace
                        if (start !== end) {
                            target.value = target.value.slice(0, start) + target.value.slice(end);
                            target.selectionStart = target.selectionEnd = start;
                        } else if (start > 0) {
                            target.value = target.value.slice(0, start - 1) + target.value.slice(start);
                            target.selectionStart = target.selectionEnd = start - 1;
                        }
                        target.dispatchEvent(new Event('input', { bubbles: true }));
                    } else if (data.vkey === 46) { // Delete
                        if (start !== end) {
                            target.value = target.value.slice(0, start) + target.value.slice(end);
                            target.selectionStart = target.selectionEnd = start;
                        } else {
                            target.value = target.value.slice(0, start) + target.value.slice(start + 1);
                            target.selectionStart = target.selectionEnd = start;
                        }
                        target.dispatchEvent(new Event('input', { bubbles: true }));
                    } else {
                        const printable = vkeyToPrintable(data.vkey);
                        if (printable) {
                            target.value = target.value.slice(0, start) + printable + target.value.slice(end);
                            target.selectionStart = target.selectionEnd = start + printable.length;
                            target.dispatchEvent(new Event('input', { bubbles: true }));
                        }
                    }
                }
            }
        } catch (e) {
            console.error('[WMonitor] Error parsing WebSocket message:', e);
        }
    };

    ws.onclose = () => {
        console.log('[WMonitor] Disconnected. Reconnecting in 3s...');
        ws = null;
        cursorEl.style.display = 'none';
        if (toolbarEl) toolbarEl.style.display = 'none';
        setTimeout(connectWebSocket, 3000);
    };

    ws.onerror = (err) => {
        console.error('[WMonitor] WebSocket Error:', err);
    };
}

function updateCursorPosition() {
    if (cursorEl) {
        cursorEl.style.left = `${localX}px`;
        cursorEl.style.top = `${localY}px`;
    }
    animationFrameId = null;
}

// Emulate a click at the current virtual cursor position
function triggerClick(x, y) {
    let displayRestore = cursorEl.style.display;
    cursorEl.style.display = 'none';

    let target = document.elementFromPoint(x, y);

    let result = attemptIframePierce(target, x, y);
    target = result.element || target;

    if (target) {
        const options = {
            view: window,
            bubbles: true,
            cancelable: true,
            clientX: x,
            clientY: y,
            button: 0
        };

        target.dispatchEvent(new MouseEvent('mousedown', options));
        target.dispatchEvent(new MouseEvent('mouseup', options));
        target.dispatchEvent(new MouseEvent('click', options));

        if (typeof target.focus === 'function') {
            target.focus();
        }
        console.log('[WMonitor] Click dispatched to:', target);
    }

    cursorEl.style.display = displayRestore;
}

function attemptIframePierce(element, x, y) {
    if (element && element.tagName === 'IFRAME') {
        try {
            const iframeDoc = element.contentDocument || element.contentWindow.document;
            if (iframeDoc) {
                const rect = element.getBoundingClientRect();
                const iframeX = x - rect.left;
                const iframeY = y - rect.top;

                const innerElement = iframeDoc.elementFromPoint(iframeX, iframeY);
                return attemptIframePierce(innerElement, iframeX, iframeY);
            }
        } catch (e) {
            return { element: element };
        }
    }
    return { element: element };
}

// VKey → KeyboardEvent.key name
function vkeyToKey(vk) {
    const map = {
        8:'Backspace',9:'Tab',13:'Enter',16:'Shift',17:'Control',18:'Alt',
        19:'Pause',20:'CapsLock',27:'Escape',32:' ',33:'PageUp',34:'PageDown',
        35:'End',36:'Home',37:'ArrowLeft',38:'ArrowUp',39:'ArrowRight',40:'ArrowDown',
        45:'Insert',46:'Delete',
        48:'0',49:'1',50:'2',51:'3',52:'4',53:'5',54:'6',55:'7',56:'8',57:'9',
        65:'a',66:'b',67:'c',68:'d',69:'e',70:'f',71:'g',72:'h',73:'i',74:'j',
        75:'k',76:'l',77:'m',78:'n',79:'o',80:'p',81:'q',82:'r',83:'s',84:'t',
        85:'u',86:'v',87:'w',88:'x',89:'y',90:'z',
        96:'0',97:'1',98:'2',99:'3',100:'4',101:'5',102:'6',103:'7',104:'8',105:'9',
        106:'*',107:'+',109:'-',110:'.',111:'/',
        112:'F1',113:'F2',114:'F3',115:'F4',116:'F5',117:'F6',
        118:'F7',119:'F8',120:'F9',121:'F10',122:'F11',123:'F12',
        186:';',187:'=',188:',',189:'-',190:'.',191:'/',192:'`',
        219:'[',220:'\\',221:']',222:"'"
    };
    return map[vk] || String.fromCharCode(vk).toLowerCase();
}

// VKey → printable character (for text insertion)
function vkeyToPrintable(vk) {
    if (vk >= 65 && vk <= 90) return String.fromCharCode(vk).toLowerCase();
    if (vk >= 48 && vk <= 57) return String.fromCharCode(vk);
    if (vk === 32) return ' ';
    const m = {186:';',187:'=',188:',',189:'-',190:'.',191:'/',192:'`',219:'[',220:'\\',221:']',222:"'"};
    return m[vk] || null;
}

// Initiate the connection
connectWebSocket();
