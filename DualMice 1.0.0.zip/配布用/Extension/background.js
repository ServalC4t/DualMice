// background.js - Handle tab operations from content script
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.action === 'newTab') {
    chrome.tabs.create({ active: true, url: 'https://www.google.com', windowId: sender.tab.windowId });
  } else if (msg.action === 'closeTab') {
    if (!sender.tab) return;
    const tabId = sender.tab.id;
    const windowId = sender.tab.windowId;
    chrome.windows.get(windowId, { populate: true }, (win) => {
      if (chrome.runtime.lastError || !win) return;
      if (win.tabs.length <= 1) {
        // このウィンドウのタブが1つだけなら閉じない
        return;
      }
      chrome.tabs.remove(tabId);
    });
  } else if (msg.action === 'prevTab') {
    if (!sender.tab) return;
    chrome.tabs.query({ windowId: sender.tab.windowId }, (tabs) => {
      if (tabs.length < 2) return;
      const idx = tabs.findIndex(t => t.id === sender.tab.id);
      const prev = (idx - 1 + tabs.length) % tabs.length;
      chrome.tabs.update(tabs[prev].id, { active: true });
    });
  } else if (msg.action === 'nextTab') {
    if (!sender.tab) return;
    chrome.tabs.query({ windowId: sender.tab.windowId }, (tabs) => {
      if (tabs.length < 2) return;
      const idx = tabs.findIndex(t => t.id === sender.tab.id);
      const next = (idx + 1) % tabs.length;
      chrome.tabs.update(tabs[next].id, { active: true });
    });
  }
});
