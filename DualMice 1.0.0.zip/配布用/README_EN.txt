================================================================
  DualMice v1.0.0
  A software that allows you to control a browser with a second mouse while playing a full-screen game.
  Developer: ServalC4t
  Project Site: https://servalc4t.github.io/my-projects/
================================================================

[Overview]
  Mouse 1 -> Controls Windows cursor and full-screen games.
  Mouse 2 -> Controls a virtual cursor independently on the browser.

  You can seamlessly operate the browser with another mouse
  while playing a game.

================================================================
[System Requirements]
  - Windows 10 / 11 (64bit)
  - Google Chrome
================================================================

[Setup Instructions]

  ■ STEP 1: Launch the Application
    Double-click "DualMice 1.0.0.exe" to start.
    * If it does not appear on the taskbar, please check the system tray (bottom right).

  ■ STEP 2: Install Chrome Extension
    1. Type the following in the Chrome address bar and open it:
         chrome://extensions/
    2. Turn ON "Developer mode" in the top right corner.
    3. Click "Load unpacked".
    4. Select the "Extension" folder included in this package.
    5. The installation is complete when the extension is added.

  ■ STEP 3: Register Mouse 2
    1. Move Mouse 2 while the application is running.
    2. The moved device will appear in "Detected Devices" at the bottom of the screen.
    3. Select the mouse you want to register and click the "Lock as Mouse 2" button.

  ■ STEP 4: Start Using
    After locking, moving Mouse 2 will display a virtual cursor on the browser.

================================================================
[Browser Toolbar (Controller) Usage]
  When the virtual cursor moves into the browser screen, a toolbar appears at the top.
  This is because you cannot interact with native browser UI elements due to extension limitations.

    <- Back     -> Go back to the previous page
    -> Forward  -> Go forward to the next page
    +           -> Open a new tab
    X           -> Close the current tab
    <-          -> Switch to the left tab
    ->          -> Switch to the right tab
    Reload      -> Reload the page
    Keyboard    -> Toggle Keyboard Mode ON/OFF

  * You can also use the side buttons (Back/Forward) on Mouse 2.

================================================================
[Keyboard Mode]
  Clicking the keyboard button on the toolbar enables Keyboard Mode.
  While in Keyboard Mode, your keyboard inputs will be forwarded to the browser.
  Click it again to disable.
  * Note: Some specific keys (like IME toggles) may not respond.

================================================================
[Settings]
  Sensitivity          -> Movement speed of the virtual cursor (Mouse 2).
  Cursor Size          -> Size of the virtual cursor.
  Opacity              -> Transparency of the virtual cursor.
  Cursor Color         -> Color of the virtual cursor.
  Lock Cursor          -> Prevents Mouse 2 from moving the Windows cursor.
  Block Clicks/Scrolls -> Suppresses Mouse 1 clicks/scrolls from triggering unexpectedly.
  Run at Startup       -> Automatically launch the app when Windows starts.

================================================================
[How to Exit]
  Clicking the 'X' button on the window will minimize it to the system tray.
  To exit completely, right-click the icon in the system tray -> "Exit".

================================================================
[Notes]
  - Since the Chrome extension is loaded in Developer Mode,
    you may see a warning when starting Chrome. You can simply click "Cancel" to ignore it.

================================================================
